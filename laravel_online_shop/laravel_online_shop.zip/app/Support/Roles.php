<?php

namespace App\Support;

class Roles
{
    const SUPER_ADMIN = 1;
    const SUB_ADMIN   = 2;
    const USER        = 3;
}
