<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Product;

class WishlistController extends Controller
{
    public function toggle(Product $product)
    {
        $wishlist = session()->get('wishlist', []);

        if (isset($wishlist[$product->id])) {
            unset($wishlist[$product->id]);
            session()->put('wishlist', $wishlist);
            return back()->with('success', 'Removed from wishlist');
        }

        $wishlist[$product->id] = true;
        session()->put('wishlist', $wishlist);

        return back()->with('success', 'Added to wishlist');
    }
}
