<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Product;

class CartController extends Controller
{
    public function index()
    {
        // صفحة cart سنبنيها لاحقاً
        return 'Cart page (TODO)';
    }

    public function add(Product $product)
    {
        $cart = session('cart', []);

        $id = $product->id;
        $price = $product->sale_price ?? $product->price;

        if (!isset($cart[$id])) {
            $cart[$id] = [
                'product_id' => $id,
                'name'       => $product->name,
                'price'      => (float) $price,
                'qty'        => 1,
                'image'      => $product->mainImage?->path,
            ];
        } else {
            $cart[$id]['qty'] = (int)$cart[$id]['qty'] + 1;
        }

        session(['cart' => $cart]);

        return back()->with('success', 'Added to cart');
    }

}
