<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Categorie;
use App\Models\Product;

class HomeController extends Controller
{
    public function index()
    {
        $categories = Categorie::query()
            ->withCount(['products' => function ($q) {
                $q->where('is_active', 1);
            }])
            ->orderBy('name')
            ->take(8)
            ->get();

        $featuredProducts = Product::query()
            ->where('is_active', 1)
            ->with(['brand', 'category', 'mainImage'])
            ->latest()
            ->take(12) // نخليها أكثر عشان الـ slider
            ->get();

        return view('user.home', compact('categories', 'featuredProducts'));
    }
}
