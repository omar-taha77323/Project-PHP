<?php

namespace App\Http\Controllers\Use;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PageController extends Controller
{
    //
}
