<?php $__env->startSection('page_title', 'Brands'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0">Brands</h3>
            <small class="text-muted">Brands Management</small>
        </div>

        <a href="<?php echo e(route('dsadmin.brands.create')); ?>" class="btn btn-primary">
            + Add Brand
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="card mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('dsadmin.brands.index')); ?>">
                <div class="row g-3 align-items-end">

                    
                    <div class="col-md-4">
                        <label class="form-label">بحث بالاسم</label>
                        <input
                            type="text"
                            name="search"
                            value="<?php echo e(request('search')); ?>"
                            class="form-control"
                            placeholder="اكتب اسم الماركة..."
                        >
                    </div>

                    
                    <div class="col-md-3">
                        <label class="form-label">الحالة</label>
                        <select name="is_visible" class="form-select">
                            <option value="">الكل</option>
                            <option value="1" <?php echo e(request('is_visible') === '1' ? 'selected' : ''); ?>>
                                ظاهرة
                            </option>
                            <option value="0" <?php echo e(request('is_visible') === '0' ? 'selected' : ''); ?>>
                                مخفية
                            </option>
                        </select>
                    </div>

                    
                    <div class="col-md-3">
                        <button class="btn btn-primary me-2" type="submit">
                            بحث
                        </button>

                        <a href="<?php echo e(route('dsadmin.brands.index')); ?>"
                           class="btn btn-outline-secondary">
                            إعادة تعيين
                        </a>
                    </div>

                </div>
            </form>
        </div>
    </div>

    
    <div class="card">
        <div class="card-body p-0">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>الاسم</th>
                        <th>الوصف</th>
                        <th>الحالة</th>
                        <th class="text-end">الإجراءات</th>
                    </tr>
                </thead>

                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($brand->id); ?></td>

                        <td class="fw-semibold">
                            <?php echo e($brand->name); ?>

                        </td>

                        <td>
                            <?php echo e(\Illuminate\Support\Str::limit($brand->description, 50)); ?>

                        </td>

                        <td>
                            <?php if($brand->is_visible): ?>
                                <span class="badge bg-success">ظاهرة</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">مخفية</span>
                            <?php endif; ?>
                        </td>

                        <td class="text-end">
                            <a href="<?php echo e(route('dsadmin.brands.edit', $brand)); ?>"
                               class="btn btn-sm btn-outline-primary">
                                تعديل
                            </a>

                            <a href="<?php echo e(route('dsadmin.brands.toggle', $brand)); ?>"
                               class="btn btn-sm btn-outline-warning">
                                تبديل الحالة
                            </a>

                            <form action="<?php echo e(route('dsadmin.brands.destroy', $brand)); ?>"
                                  method="POST"
                                  class="d-inline"
                                  onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger">
                                    حذف
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4 text-muted">
                            لا توجد علامات تجارية بعد
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="mt-3">
        <?php echo e($brands->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dsadmin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\Project-Lastversion\Project-PHP\laravel_online_shop\resources\views/dsadmin/brands/index.blade.php ENDPATH**/ ?>