<?php $__env->startSection('page_title', 'المنتجات'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0">Products</h3>
            <small class="text-muted">Products Management</small>
        </div>
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">+ Add Product</a>
    </div>
    
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>

    
    <div class="card mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('products.index')); ?>">
                <div class="row g-3 align-items-end">

                    
                    <div class="col-md-4">
                        <label class="form-label">بحث بالاسم أو SKU</label>
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="اكتب اسم المنتج أو SKU...">
                    </div>

                    
                    <div class="col-md-3">
                        <label class="form-label">القسم</label>
                        <select name="category_id" class="form-select">
                            <option value="">الكل</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?>>
                                    <?php echo e($cat->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    
                    <div class="col-md-3">
                        <label class="form-label">العلامة التجارية</label>
                        <select name="brand_id" class="form-select">
                            <option value="">الكل</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>" <?php echo e(request('brand_id') == $brand->id ? 'selected' : ''); ?>>
                                    <?php echo e($brand->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    
                    <div class="col-md-2">
                        <label class="form-label">الحالة</label>
                        <select name="is_active" class="form-select">
                            <option value="">الكل</option>
                            <option value="1" <?php echo e(request('is_active') === '1' ? 'selected' : ''); ?>>نشط</option>
                            <option value="0" <?php echo e(request('is_active') === '0' ? 'selected' : ''); ?>>غير نشط</option>
                        </select>
                    </div>

                    
                    <div class="col-md-12 mt-2">
                        <button class="btn btn-primary me-2" type="submit">بحث</button>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-secondary">إعادة تعيين</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>صورة</th>
                            <th>اسم المنتج</th>
                            <th>القسم</th>
                            <th>العلامة التجارية</th>
                            <th>السعر</th>
                            <th>المخزون</th>
                            <th>الحالة</th>
                            <th class="text-end">إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($product->id); ?></td>

                                
                                <td>
                                    <?php if($product->images && count($product->images) > 0): ?>
                                        <img src="<?php echo e(asset('storage/' . $product->images[0]->path)); ?>" alt="<?php echo e($product->name); ?>" class="img-thumbnail" style="width:50px; height:50px; object-fit:cover;">
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>

                                
                                <td class="fw-semibold">
                                    <?php echo e($product->name); ?>

                                    <?php if(!empty($product->sku)): ?>
                                        <div class="text-muted small">SKU: <?php echo e($product->sku); ?></div>
                                    <?php endif; ?>
                                </td>

                                
                                <td><?php echo e($product->category ? $product->category->name : 'بدون قسم'); ?></td>

                                
                                <td><?php echo e($product->brand ? $product->brand->name : 'بدون علامة تجارية'); ?></td>

                                
                                <td>$<?php echo e(number_format($product->price, 2)); ?></td>

                                
                                <td>
                                    <?php if($product->stock == 0): ?>
                                        <span class="badge bg-danger">نفذ</span>
                                    <?php elseif($product->stock < 5): ?>
                                        <span class="badge bg-warning text-dark">قليل</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">متوفر</span>
                                    <?php endif; ?>
                                    <span class="text-muted">(<?php echo e($product->stock); ?>)</span>
                                </td>

                                
                                <td>
                                    <?php if($product->is_active): ?>
                                        <span class="badge bg-success">نشط</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">غير نشط</span>
                                    <?php endif; ?>
                                </td>

                                
                                <td class="text-end">
                                    <a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-sm btn-outline-secondary">تعديل</a>

                                    <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST" class="d-inline"
                                        onsubmit="return confirm('هل أنت متأكد من حذف المنتج؟');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger">حذف</button>
                                    </form>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted py-4">
                                    لا يوجد منتجات بعد
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <div class="card-footer">
            <?php echo e($products->links()); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dsadmin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\Project-Lastversion\Project-PHP\laravel_online_shop\resources\views/dsadmin/products/index.blade.php ENDPATH**/ ?>