<?php $__env->startSection('content'); ?>
<div class="container">

    

    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0">Admin Users</h3>
            <small class="text-muted">Admin Users Management</small>
        </div>

        <a href="<?php echo e($role == 1 ? url('/super-admins/create') : url('/sub-admins/create')); ?>" class="btn btn-primary">
            + Add Admin User
        </a>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>الاسم</th>
                <th>الإيميل</th>
                <th>تاريخ الإنشاء</th>
                <th>إجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($u->id); ?></td>
                <td><?php echo e($u->name); ?></td>
                <td><?php echo e($u->email); ?></td>
                <td><?php echo e($u->created_at ? $u->created_at->format('Y-m-d') : ''); ?></td>
                <td>
                    <a class="btn btn-sm btn-warning"
                        href="<?php echo e($role == 1 ? url('/super-admins/'.$u->id.'/edit') : url('/sub-admins/'.$u->id.'/edit')); ?>">
                        تعديل
                    </a>

                    <form method="POST"
                        action="<?php echo e($role == 1 ? url('/super-admins/'.$u->id) : url('/sub-admins/'.$u->id)); ?>"
                        style="display:inline-block"
                        onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger">حذف</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($users->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dsadmin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\Project-Lastversion\Project-PHP\laravel_online_shop\resources\views/dsadmin/admin_users/index.blade.php ENDPATH**/ ?>