<?php $__env->startSection('title', 'Product Listing - Shop'); ?>

<?php $__env->startSection('content'); ?>
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        
        <nav aria-label="Breadcrumb" class="flex text-sm text-gray-500 dark:text-gray-400 mb-6">
            <ol class="flex items-center space-x-2">
                <li><a class="hover:text-primary" href="<?php echo e(route('user.home')); ?>">Home</a></li>
                <li class="flex items-center space-x-2">
                    <span class="material-symbols-outlined text-base">chevron_right</span>
                    <a class="hover:text-primary" href="<?php echo e(route('user.products.index')); ?>">Shop</a>
                </li>
                <li class="flex items-center space-x-2">
                    <span class="material-symbols-outlined text-base">chevron_right</span>
                    <span class="text-gray-900 dark:text-white font-medium">All Products</span>
                </li>
            </ol>
        </nav>

        <div class="flex flex-col lg:flex-row gap-8">

            
            <aside class="w-full lg:w-64 flex-shrink-0">
                <form method="GET" action="<?php echo e(route('user.products.index')); ?>"
                      class="sticky top-24 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-5 space-y-8">

                    <div class="flex items-center justify-between mb-2">
                        <h3 class="text-gray-900 dark:text-white font-bold text-lg">Filters</h3>
                        <a href="<?php echo e(route('user.products.index')); ?>" class="text-primary text-xs font-semibold hover:underline">Reset</a>
                    </div>

                    
                    <?php if(request('q')): ?>
                        <input type="hidden" name="q" value="<?php echo e(request('q')); ?>">
                    <?php endif; ?>

                    
                    <div class="space-y-3">
                        <h4 class="text-gray-900 dark:text-white text-sm font-semibold uppercase tracking-wider">Categories</h4>
                        <div class="space-y-2">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $checked = in_array((string)$cat->id, (array)request('categories', []), true);
                                ?>
                                <label class="flex items-center justify-between group cursor-pointer">
                                    <div class="flex items-center gap-3">
                                        <input
                                            name="categories[]"
                                            value="<?php echo e($cat->id); ?>"
                                            <?php if($checked): echo 'checked'; endif; ?>
                                            class="h-5 w-5 rounded border-gray-300 dark:border-gray-700 text-primary focus:ring-primary checkbox-custom"
                                            type="checkbox"
                                        />
                                        <span class="text-gray-600 dark:text-gray-400 text-sm group-hover:text-primary transition-colors <?php echo e($checked ? 'font-medium' : ''); ?>">
                                            <?php echo e($cat->name); ?>

                                        </span>
                                    </div>
                                    <span class="text-xs text-gray-400"><?php echo e($cat->products_count); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    
                    <div>
                        <h4 class="text-gray-900 dark:text-white text-sm font-semibold uppercase tracking-wider mb-4">Price Range</h4>
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="text-xs text-gray-500">Min</label>
                                <input
                                    name="min_price"
                                    value="<?php echo e(request('min_price')); ?>"
                                    type="number" step="0.01" min="0"
                                    class="mt-1 block w-full border-none bg-gray-100 dark:bg-gray-800 rounded-lg text-sm placeholder-gray-500 focus:ring-2 focus:ring-primary dark:text-gray-200"
                                    placeholder="0"
                                />
                            </div>
                            <div>
                                <label class="text-xs text-gray-500">Max</label>
                                <input
                                    name="max_price"
                                    value="<?php echo e(request('max_price')); ?>"
                                    type="number" step="0.01" min="0"
                                    class="mt-1 block w-full border-none bg-gray-100 dark:bg-gray-800 rounded-lg text-sm placeholder-gray-500 focus:ring-2 focus:ring-primary dark:text-gray-200"
                                    placeholder="9999"
                                />
                            </div>
                        </div>
                        <p class="text-[11px] text-gray-400 mt-2">
                            Range: <?php echo e(number_format($priceMin, 2)); ?> - <?php echo e(number_format($priceMax, 2)); ?>

                        </p>
                    </div>

                    
                    <div>
                        <h4 class="text-gray-900 dark:text-white text-sm font-semibold uppercase tracking-wider mb-4">Brands</h4>
                        <div class="space-y-2">
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $bChecked = in_array((string)$b->id, (array)request('brands', []), true);
                                ?>
                                <label class="flex items-center gap-3 cursor-pointer">
                                    <input
                                        name="brands[]"
                                        value="<?php echo e($b->id); ?>"
                                        <?php if($bChecked): echo 'checked'; endif; ?>
                                        class="h-5 w-5 rounded border-gray-300 dark:border-gray-700 text-primary checkbox-custom"
                                        type="checkbox"
                                    />
                                    <span class="text-gray-600 dark:text-gray-400 text-sm"><?php echo e($b->name); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    
                    <button class="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2">
                        <span>Apply Filters</span>
                    </button>
                </form>
            </aside>

            
            <div class="flex-1">

                
                <div class="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4 bg-white dark:bg-gray-900 p-4 rounded-xl border border-gray-200 dark:border-gray-800">
                    <div class="text-sm text-gray-600 dark:text-gray-400">
                        Showing
                        <span class="font-bold text-gray-900 dark:text-white"><?php echo e($products->count()); ?></span>
                        of
                        <span class="font-bold text-gray-900 dark:text-white"><?php echo e($products->total()); ?></span>
                        products
                    </div>

                    <div class="flex items-center gap-3">
                        <span class="text-sm text-gray-600 dark:text-gray-400 whitespace-nowrap">Sort by:</span>

                        <form method="GET" action="<?php echo e(route('user.products.index')); ?>">
                            
                            <?php $__currentLoopData = request()->except('sort', 'page'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(is_array($v)): ?>
                                    <?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="hidden" name="<?php echo e($k); ?>[]" value="<?php echo e($vv); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <input type="hidden" name="<?php echo e($k); ?>" value="<?php echo e($v); ?>">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <select name="sort" onchange="this.form.submit()"
                                    class="bg-gray-50 dark:bg-gray-800 border-none rounded-lg text-sm text-gray-900 dark:text-white focus:ring-primary pr-10">
                                <option value="new" <?php if(request('sort', 'new') === 'new'): echo 'selected'; endif; ?>>Newest Arrivals</option>
                                <option value="price_asc" <?php if(request('sort') === 'price_asc'): echo 'selected'; endif; ?>>Price: Low to High</option>
                                <option value="price_desc" <?php if(request('sort') === 'price_desc'): echo 'selected'; endif; ?>>Price: High to Low</option>
                            </select>
                        </form>
                    </div>
                </div>

                
                <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">

                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $img = $p->mainImage?->path;
                            $finalPrice = $p->sale_price ?? $p->price;
                            $hasSale = !is_null($p->sale_price) && (float)$p->sale_price < (float)$p->price;
                        ?>

                        <div class="group bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden hover:shadow-xl transition-all duration-300">
                            <a href="<?php echo e(route('user.products.show', $p->id)); ?>" class="block relative aspect-square overflow-hidden bg-gray-100">
                                <?php if($img): ?>
                                    <img class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                                         alt="<?php echo e($p->name); ?>"
                                         src="<?php echo e(asset($img)); ?>"/>
                                <?php else: ?>
                                    <img class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                                         alt="<?php echo e($p->name); ?>"
                                         src="https://picsum.photos/seed/product-<?php echo e($p->id); ?>/800/800"/>
                                <?php endif; ?>

                                <?php if($hasSale): ?>
                                    <div class="absolute top-3 left-3 bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded uppercase">
                                        SALE
                                    </div>
                                <?php endif; ?>

                                
                                <form method="POST" action="<?php echo e(route('user.wishlist.toggle', $p->id)); ?>"
                                      class="absolute top-3 right-3">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                            class="p-2 bg-white/80 dark:bg-black/40 backdrop-blur-md rounded-full text-gray-900 dark:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                                        <span class="material-symbols-outlined text-xl">favorite</span>
                                    </button>
                                </form>
                            </a>

                            <div class="p-5">
                                <p class="text-xs text-primary font-bold uppercase tracking-wider mb-1">
                                    <?php echo e($p->category?->name ?? '—'); ?>

                                </p>

                                <h3 class="text-gray-900 dark:text-white font-bold text-lg mb-2 line-clamp-1">
                                    <?php echo e($p->name); ?>

                                </h3>

                                <div class="flex items-center justify-between">
                                    <div class="flex flex-col">
                                        <span class="text-gray-900 dark:text-white font-bold text-xl">
                                            $<?php echo e(number_format($finalPrice, 2)); ?>

                                        </span>

                                        <?php if($hasSale): ?>
                                            <span class="text-gray-400 text-sm line-through">
                                                $<?php echo e(number_format($p->price, 2)); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <form method="POST" action="<?php echo e(route('user.cart.add', $p->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button class="p-3 bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white rounded-lg hover:bg-primary hover:text-white transition-colors"
                                                type="submit">
                                            <span class="material-symbols-outlined">shopping_cart</span>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-gray-500">No products found.</div>
                    <?php endif; ?>

                </div>

                
                <div class="mt-12">
                    <?php echo e($products->links()); ?>

                </div>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\Project-Lastversion\Project-PHP\laravel_online_shop\resources\views/user/products/index.blade.php ENDPATH**/ ?>