<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<?php
  use Illuminate\Support\Str;

  $wishlist = session('wishlist', []);
  $inWishlist = isset($wishlist[$product->id]);

  $images = $product->images ?? collect();
  $main = $product->mainImage ?: $images->first();

  $imgUrl = $main?->path
    ? (Str::startsWith($main->path, ['http://','https://']) ? $main->path : asset('storage/'.$main->path))
    : 'https://via.placeholder.com/800x600?text=No+Image';

  $price = $product->sale_price ?? $product->price;
?>

<main class="flex flex-col items-center py-6 px-4 md:px-10">
  <div class="max-w-[1200px] w-full flex flex-col">

    
    <nav class="flex flex-wrap gap-2 py-4 mb-2">
      <a class="text-[#617c89] dark:text-gray-400 text-sm font-medium hover:text-primary" href="<?php echo e(route('user.products.index')); ?>">Shop</a>
      <span class="text-[#617c89] dark:text-gray-400 text-sm font-medium">/</span>

      <?php if($product->category): ?>
        <span class="text-[#617c89] dark:text-gray-400 text-sm font-medium"><?php echo e($product->category->name); ?></span>
        <span class="text-[#617c89] dark:text-gray-400 text-sm font-medium">/</span>
      <?php endif; ?>

      <span class="text-primary text-sm font-medium"><?php echo e($product->name); ?></span>
    </nav>

    
    <div class="grid grid-cols-12 gap-8 bg-white dark:bg-background-dark p-6 md:p-8 rounded-xl shadow-sm border border-gray-100 dark:border-gray-800">

      
      <div class="col-span-12 lg:col-span-7 flex flex-col gap-4">
        <div class="w-full aspect-[4/3] rounded-xl overflow-hidden bg-[#f0f3f4] dark:bg-gray-800">
          <div class="w-full h-full bg-center bg-no-repeat bg-cover" style="background-image:url('<?php echo e($imgUrl); ?>')"></div>
        </div>

        
        <?php if($images->count()): ?>
          <div class="grid grid-cols-5 gap-3">
            <?php $__currentLoopData = $images->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $thumb = Str::startsWith($img->path, ['http://','https://']) ? $img->path : asset('storage/'.$img->path);
              ?>
              <a href="<?php echo e($thumb); ?>" target="_blank"
                 class="aspect-square rounded-lg border-2 <?php echo e($img->is_main ? 'border-primary' : 'border-transparent hover:border-primary/50'); ?>

                        overflow-hidden cursor-pointer bg-[#f0f3f4] transition-all">
                <div class="w-full h-full bg-center bg-no-repeat bg-cover" style="background-image:url('<?php echo e($thumb); ?>')"></div>
              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>

      
      <div class="col-span-12 lg:col-span-5 flex flex-col">
        <div class="mb-4">
          <p class="text-[#617c89] dark:text-gray-400 text-sm font-medium uppercase">
            <?php echo e($product->brand?->name ?? 'Product'); ?>

          </p>
          <h1 class="text-[#111618] dark:text-white text-3xl md:text-4xl font-extrabold mb-2">
            <?php echo e($product->name); ?>

          </h1>
          <p class="text-[#617c89] dark:text-gray-400 text-sm">SKU: <?php echo e($product->sku); ?></p>
        </div>

        <div class="flex items-center gap-4 mb-6">
          <span class="text-3xl font-bold text-[#111618] dark:text-white">$<?php echo e(number_format($price, 2)); ?></span>

          <?php if($product->stock > 0): ?>
            <div class="flex items-center gap-1.5 px-3 py-1 bg-green-50 dark:bg-green-950/30 text-green-600 dark:text-green-400 rounded-full border border-green-100 dark:border-green-900">
              <span class="material-symbols-outlined text-[16px]">check_circle</span>
              <span class="text-xs font-bold uppercase">In Stock</span>
            </div>
          <?php else: ?>
            <div class="flex items-center gap-1.5 px-3 py-1 bg-red-50 dark:bg-red-950/30 text-red-600 dark:text-red-400 rounded-full border border-red-100 dark:border-red-900">
              <span class="material-symbols-outlined text-[16px]">cancel</span>
              <span class="text-xs font-bold uppercase">Out of Stock</span>
            </div>
          <?php endif; ?>
        </div>

        <div class="mb-8 space-y-4">
          <h3 class="text-sm font-bold text-[#111618] dark:text-white uppercase">Product Description</h3>
          <p class="text-[#4b5563] dark:text-gray-300 text-base leading-relaxed">
            <?php echo e($product->description ?: 'No description available.'); ?>

          </p>
        </div>

        
        <div class="flex flex-col gap-4 mt-auto">

          
          <form action="<?php echo e(route('user.cart.add', $product)); ?>" method="POST" class="flex gap-4">
            <?php echo csrf_field(); ?>

            <div class="flex items-center border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden h-12">
              <button type="button" onclick="decQty()" class="px-4 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 h-full flex items-center justify-center">
                <span class="material-symbols-outlined text-[18px]">remove</span>
              </button>

              <input id="qty" name="qty" value="1"
                     class="w-14 text-center font-bold bg-transparent border-0 focus:ring-0 text-[#111618] dark:text-white" />

              <button type="button" onclick="incQty()" class="px-4 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 h-full flex items-center justify-center">
                <span class="material-symbols-outlined text-[18px]">add</span>
              </button>
            </div>

            <button <?php if($product->stock <= 0): echo 'disabled'; endif; ?>
                    class="flex-1 bg-primary hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-lg transition-all flex items-center justify-center gap-2 h-12 shadow-md shadow-primary/20">
              <span class="material-symbols-outlined">shopping_bag</span>
              Add to Cart
            </button>
          </form>

          
          <form action="<?php echo e(route('user.wishlist.toggle', $product)); ?>" method="POST" class="flex gap-3">
            <?php echo csrf_field(); ?>
            <button class="flex-1 flex items-center justify-center gap-2 border border-gray-200 dark:border-gray-700 py-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-sm font-medium h-12">
              <span class="material-symbols-outlined text-[20px] <?php echo e($inWishlist ? 'text-red-500' : ''); ?>">favorite</span>
              <?php echo e($inWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'); ?>

            </button>
          </form>

        </div>
      </div>
    </div>

    
    <?php if($related->count()): ?>
      <div class="mt-10">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-xl font-bold text-[#111618] dark:text-white">Related Products</h2>
          <a href="<?php echo e(route('user.products.index')); ?>" class="text-primary text-sm font-semibold hover:underline">Back to shop</a>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $rimg = $p->mainImage?->path
                ? (Str::startsWith($p->mainImage->path, ['http://','https://']) ? $p->mainImage->path : asset('storage/'.$p->mainImage->path))
                : 'https://via.placeholder.com/600x600?text=No+Image';
              $rprice = $p->sale_price ?? $p->price;
            ?>
            <a href="<?php echo e(route('user.products.show', $p)); ?>" class="group bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden hover:shadow-xl transition-all">
              <div class="relative aspect-square overflow-hidden bg-gray-100">
                <img src="<?php echo e($rimg); ?>" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="<?php echo e($p->name); ?>">
              </div>
              <div class="p-4">
                <div class="text-sm font-bold text-[#111618] dark:text-white line-clamp-1"><?php echo e($p->name); ?></div>
                <div class="text-primary font-bold mt-2">$<?php echo e(number_format($rprice, 2)); ?></div>
              </div>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    <?php endif; ?>

  </div>
</main>

<script>
  function incQty() {
    const el = document.getElementById('qty');
    const v = parseInt(el.value || '1', 10);
    el.value = Math.min(99, v + 1);
  }
  function decQty() {
    const el = document.getElementById('qty');
    const v = parseInt(el.value || '1', 10);
    el.value = Math.max(1, v - 1);
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\Project-Lastversion\Project-PHP\laravel_online_shop\resources\views/user/products/show.blade.php ENDPATH**/ ?>