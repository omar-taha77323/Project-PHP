<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    

    <?php $__env->startSection('title', 'Categories'); ?>

    <?php $__env->startSection('content'); ?>

        <main class="flex-1 w-full max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-10 py-8">

            
            <nav class="flex items-center gap-2 mb-6 text-sm text-gray-500">
                <a href="<?php echo e(route('user.home')); ?>" class="hover:text-primary flex items-center gap-1">
                    <span class="material-symbols-outlined text-base">home</span>
                    Home
                </a>
                <span class="material-symbols-outlined text-xs">chevron_right</span>
                <span class="font-semibold">Categories</span>
            </nav>

            
            <div class="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
                <div class="space-y-2">
                    <h1 class="text-4xl font-black tracking-tight">Shop by Category</h1>
                    <p class="text-gray-600 text-lg">Browse our curated collections (<?php echo e($categories->count()); ?> available)</p>
                </div>
            </div>

            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">

                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $image = $category->image ? asset('storage/' . $category->image) : 'https://via.placeholder.com/600x600?text=No+Image';
                    ?>

                    <a href="<?php echo e(route('categories.show', $category->slug)); ?>"
                       class="group relative overflow-hidden rounded-xl bg-gray-900/5 dark:bg-white/5 shadow-sm hover:shadow-xl transition-all duration-300">

                        <div class="aspect-square w-full overflow-hidden">
                            <img src="<?php echo e($image); ?>" alt="<?php echo e($category->name); ?>" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                        </div>

                        <div class="absolute inset-0 flex flex-col justify-end p-6 bg-gradient-to-t from-black/50 to-transparent">
                            <p class="text-white/80 text-xs font-bold uppercase tracking-widest mb-1"><?php echo e($category->products_count ?? 0); ?> Products</p>

                            <h3 class="text-white text-2xl font-bold mb-4"><?php echo e($category->name); ?></h3>

                            <div class="opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                                <span class="w-full bg-primary text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2">Explore <span class="material-symbols-outlined">chevron_right</span></span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-4 text-center text-gray-500">No categories available.</div>
                <?php endif; ?>

            </div>

        </main>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\Project-Lastversion\Project-PHP\laravel_online_shop\resources\views/user/categories/index.blade.php ENDPATH**/ ?>