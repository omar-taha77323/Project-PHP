<?php $__env->startSection('title', 'Home Page - Laravel Store'); ?>

<?php $__env->startSection('content'); ?>
<div class="layout-content-container flex flex-col max-w-[1200px] w-full px-4 md:px-10">

    
    <div class="py-6">
        <div class="@container">
            <div class="flex min-h-[520px] flex-col gap-6 bg-cover bg-center bg-no-repeat rounded-xl items-start justify-end px-6 pb-16 md:px-12 md:pb-20 relative overflow-hidden group"
                 style='background-image: linear-gradient(rgba(0, 0, 0, 0.2) 0%, rgba(0, 0, 0, 0.6) 100%), url("https://lh3.googleusercontent.com/aida-public/AB6AXuARz6JC1LXJihF505lfvJzk7ZNuRNI7g_x-rnIrBchNUdDV-oiNU_2fI7QH1NswM_E2A4LdhlYC0fHhS4sK7VGNMzUaUR_ptZzu7D4ghmGWx-HVwk0FTqgCOpzoDpMuxWZlbJT0HZKyQpaFgzqJa_eghPZA_dKNSzr77gvfFwI71kIl07lXegU8gMD6TEEUi4pWOYQjjlDUFhPWblAyDAHA_-eiBk6sNxRLBw2d7SQqfl5rLV2ybgtx5yAZzTg0k-125Q4LGa7khdM");'>
                <div class="flex flex-col gap-4 text-left max-w-2xl z-10">
                    <h1 class="text-white text-5xl font-black leading-tight tracking-[-0.033em] md:text-6xl">
                        Discover Your Next Favorite Essential
                    </h1>
                    <p class="text-white/90 text-lg font-normal leading-relaxed md:text-xl">
                        Curated collections designed for your lifestyle. High-quality products, minimalist design, and sustainable materials at your fingertips.
                    </p>
                </div>

                <a href="<?php echo e(route('user.products.index')); ?>"
                   class="flex min-w-[160px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-6 bg-primary text-white text-base font-bold leading-normal tracking-[0.015em] hover:bg-primary/90 transition-all z-10 shadow-lg shadow-primary/20">
                    <span class="truncate">Shop Collection</span>
                </a>
            </div>
        </div>
    </div>

    
    <div class="flex items-center justify-between px-4 pb-4 pt-8">
        <h2 class="text-[#111618] dark:text-white text-2xl font-bold leading-tight tracking-[-0.015em]">Shop by Category</h2>
        <a class="text-primary font-semibold text-sm hover:underline" href="<?php echo e(route('user.categories.index')); ?>">View all</a>
    </div>

    
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 px-4 pb-8">
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('user.categories.show', $cat->id)); ?>" class="group cursor-pointer">
                <div class="relative aspect-square rounded-xl overflow-hidden mb-3 bg-gray-100 dark:bg-gray-800">
                    
                    <div class="w-full h-full bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                         style='background-image: url("https://picsum.photos/seed/category-<?php echo e($cat->id); ?>/600/600");'></div>

                    <div class="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                        <span class="text-white font-bold text-lg"><?php echo e($cat->name); ?></span>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-gray-500 px-4">No categories found.</div>
        <?php endif; ?>
    </div>

    
    <div class="flex items-center justify-between px-4 pb-4 pt-8">
        <h2 class="text-[#111618] dark:text-white text-2xl font-bold leading-tight tracking-[-0.015em]">Featured Products</h2>
        <a class="text-primary font-semibold text-sm hover:underline" href="<?php echo e(route('user.products.index')); ?>">See all products</a>
    </div>

    
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-4">
        <?php $__empty_1 = true; $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex flex-col group bg-white dark:bg-gray-900 rounded-xl p-3 border border-transparent hover:border-gray-200 dark:hover:border-gray-800 transition-all hover:shadow-xl hover:shadow-gray-200/50 dark:hover:shadow-none">
                <a href="<?php echo e(route('user.products.show', $p->id)); ?>"
                   class="relative w-full aspect-square bg-center bg-no-repeat bg-cover rounded-lg overflow-hidden"
                   style='background-image: url("<?php echo e($p->mainImage?->path ? asset($p->mainImage->path) : "https://picsum.photos/seed/product-".$p->id."/800/800"); ?>");'>

                    <div class="absolute top-2 right-2">
                        
                        <form method="POST" action="<?php echo e(route('user.wishlist.toggle', $p->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="bg-white/90 dark:bg-black/50 p-2 rounded-full text-gray-500 hover:text-red-500 transition-colors">
                                <span class="material-symbols-outlined text-sm">favorite</span>
                            </button>
                        </form>
                    </div>
                </a>

                <div class="mt-4 flex flex-col gap-1">
                    <p class="text-[#111618] dark:text-white text-base font-bold leading-normal truncate"><?php echo e($p->name); ?></p>
                    <p class="text-[#617c89] dark:text-gray-400 text-sm font-normal leading-normal">
                        <?php echo e($p->brand?->name ?? '—'); ?>

                    </p>

                    <div class="flex items-center justify-between mt-3">
                        <p class="text-primary text-lg font-bold leading-normal">
                            $<?php echo e(number_format($p->sale_price ?? $p->price, 2)); ?>

                        </p>

                        <form method="POST" action="<?php echo e(route('user.cart.add', $p->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="bg-primary/10 text-primary hover:bg-primary hover:text-white px-3 py-1.5 rounded-lg text-sm font-bold transition-all flex items-center gap-1">
                                <span class="material-symbols-outlined text-base">add_shopping_cart</span>
                                Add
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-gray-500 px-4">No products found.</div>
        <?php endif; ?>
    </div>

    
    <div class="py-12 px-4 w-full">
        <div class="bg-primary/10 dark:bg-gray-900 rounded-2xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8 border border-primary/20">
            <div class="max-w-md text-center md:text-left">
                <h3 class="text-2xl font-bold text-[#111618] dark:text-white mb-2">Join our Newsletter</h3>
                <p class="text-gray-600 dark:text-gray-400">Get early access to new collections and exclusive discounts delivered straight to your inbox.</p>
            </div>

            <form method="POST" action="<?php echo e(route('user.newsletter.subscribe')); ?>" class="flex w-full max-w-sm gap-2">
                <?php echo csrf_field(); ?>
                <input name="email" type="email"
                       class="flex-1 rounded-lg border-gray-200 dark:border-gray-800 dark:bg-gray-800 dark:text-white focus:ring-primary focus:border-primary"
                       placeholder="Enter your email" required/>
                <button class="bg-primary text-white font-bold px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors">
                    Subscribe
                </button>
            </form>
        </div>

        <?php if(session('success')): ?>
            <div class="mt-4 px-4 text-sm text-green-700"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\Project-Lastversion\Project-PHP\laravel_online_shop\resources\views/user/pages/home.blade.php ENDPATH**/ ?>