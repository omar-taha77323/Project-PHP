<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('Team Coder', 'ElectroStore')); ?></title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    <link rel="stylesheet" href="<?php echo e(asset('admin-assets/css/style-welcome.css')); ?>">
</head>

<body class="antialiased">    <div class="hero-wrap min-h-screen bg-dots-darker bg-center bg-gray-100">

        
        <div class="topbar">
            <div class="inline-flex" style="gap:.75rem; align-items:center;">
                <span class="badge"><img src="<?php echo e(asset('admin-assets/img/AdminLogo.png  with=100px, height=100px')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8"><span>ElectroStore</span></span>
            </div>

            <?php if(Route::has('login')): ?>
            <div class="inline-flex" style="gap: 1rem; align-items:center;">
                <?php if(auth()->guard()->check()): ?>
                <?php
                $role = (int) (auth()->user()->role_id ?? 3);
                $isAdminPanel = in_array($role, [1,2]);
                ?>

                <?php if($isAdminPanel): ?>
                <a class="link" href="<?php echo e(url('/dashboard')); ?>">لوحة التحكم</a>
                <?php else: ?>
                <a class="link" href="<?php echo e(url('/')); ?>">الرئيسية</a>
                <?php endif; ?>

                <a class="link" href="<?php echo e(route('logout')); ?>"
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    Logout
                </a>
                <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                </form>
                <?php else: ?>
                <a class="link" href="<?php echo e(route('login')); ?>">Log in</a>
                <?php if(Route::has('register')): ?>
                <a class="link" href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        
        <div class="flex items-center justify-center px-6 py-10">
            <div class="w-full max-w-3xl card p-6">

                <div class="text-center" style="margin-top: .5rem;">

                    <h1 class="text-5xl font-bold text-gray-900" style="margin-top: 1rem;">
                     <span style="text-decoration: underline;"><?php echo e(config('Team Coder', 'ElectroStore')); ?></span>
                    </h1>

                    
                </div>

                <div class="divider"></div>

                
                <div class="grid gap-4">
                    

                    <div class="menu">
                        
                        <?php if(auth()->guard()->check()): ?>
                        <?php
                        $role = (int) (auth()->user()->role_id ?? 3);
                        $isAdminPanel = in_array($role, [1,2]);
                        ?>

                        <?php if($isAdminPanel): ?>
                        <a class="tile transition" href="<?php echo e(url('/dashboard')); ?>">📊 Dashboard</a>
                        <a class="tile transition" href="<?php echo e(url('/categories')); ?>">🏷️ Category</a>
                        <a class="tile transition" href="<?php echo e(url('/sub-categories')); ?>">📑 Sub Category</a>
                        <a class="tile transition" href="<?php echo e(url('/brands')); ?>">™️ Brands</a>
                        <a class="tile transition" href="<?php echo e(url('/products')); ?>">📦 Products</a>
                        <a class="tile transition" href="<?php echo e(url('/shipping')); ?>">🚚 Shipping</a>
                        <a class="tile transition" href="<?php echo e(url('/orders')); ?>">🧾 Orders</a>
                        <a class="tile transition" href="<?php echo e(url('/discounts')); ?>">💰 Discount</a>
                        
                        <a class="tile transition" href="<?php echo e(url('/pages')); ?>">📄 Pages</a>

                        
                        <?php if($role === 1): ?>
                        <a class="tile transition" href="<?php echo e(url('/super-admins')); ?>">🛡️ Super Admins</a>
                        <a class="tile transition" href="<?php echo e(url('/sub-admins')); ?>">👮 Sub Admins</a>
                        <a class="tile transition" href="<?php echo e(url('/customers')); ?>">👥 Customers</a>
                        
                        <?php endif; ?>
                        <?php else: ?>
                        <div class="tile">
                             أنت User (role_id = 3). لا توجد لوحة إدارة هنا.
                            إذا تريد صفحة مستخدم خاصة، نضيف routes و views لها.
                        </div>
                        <?php endif; ?>
                        <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary transition">تسجيل الدخول →</a>
                        <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-ghost transition">إنشاء حساب جديد</a>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>

                    
                </div>

                <div class="divider"></div>

                <div class="text-center text-sm muted">
                    <span>© <?php echo e(date('Y')); ?></span>
                    <span>—</span>
                    <span><?php echo e(config('Team Coder', 'ElectroStore')); ?></span>
                </div>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH C:\xampp\php\Project-Lastversion\Project-PHP\laravel_online_shop\resources\views/welcome.blade.php ENDPATH**/ ?>