<?php $__env->startSection('content'); ?>

<div class="container py-4">
<div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h3 class="mb-0 fw-bold">Discount</h3>
            <small class="text-muted">Discount Management</small>
        </div>
      
        <a href="#" class="btn btn-primary">
            + Add Discount
        </a>    
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dsadmin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\Project-Lastversion\Project-PHP\laravel_online_shop\resources\views/dsadmin/discount/index.blade.php ENDPATH**/ ?>